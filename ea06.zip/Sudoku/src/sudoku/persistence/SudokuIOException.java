package sudoku.persistence;

public class SudokuIOException extends Exception {
}
