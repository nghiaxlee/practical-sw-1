package tictactoe;

public enum Player {
    X, O, NOBODY
}
