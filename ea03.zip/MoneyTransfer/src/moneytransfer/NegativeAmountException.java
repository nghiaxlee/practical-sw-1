package moneytransfer;


public class NegativeAmountException extends Exception {

    public NegativeAmountException() {
    }
    
}
