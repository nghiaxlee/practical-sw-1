package house;

public interface Room {

    public void draw();

}
