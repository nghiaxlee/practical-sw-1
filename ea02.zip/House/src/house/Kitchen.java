package house;

public class Kitchen implements Room {

    @Override
    public void draw() {
        System.out.println("Kitchen");
    }

    public Kitchen() {
    }

}
