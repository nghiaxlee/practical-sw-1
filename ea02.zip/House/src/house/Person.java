package house;

public class Person {

    public final String name;

    public Person(String name) {
        this.name = name;
    }

}
